import React, { useRef, useState } from "react";
import {
  ArrowUpRight,
  Info,
  ChevronDown,
  UploadCloud,
  Plus,
  LoaderCircle,
  CircleCheck,
} from "lucide-react";
function today() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
type FormErrors = Record<string, string>;
function FormField({
  name,
  label,
  required,
  children,
  errors,
}: {
  name: string;
  label: string;
  required?: boolean;
  children: React.ReactNode;
  errors: FormErrors;
}) {
  if (name === "contactMethod")
    return (
      <fieldset className="form-field contact-fieldset">
        <legend>{label}</legend>
        {children}
      </fieldset>
    );
  return (
    <div className={`form-field ${errors[name] ? "has-error" : ""}`}>
      <label htmlFor={name}>
        {label}
        {required && <span aria-hidden="true"> *</span>}
      </label>
      {children}
      {errors[name] && (
        <span className="field-error" id={`${name}-error`}>
          {errors[name]}
        </span>
      )}
    </div>
  );
}
export default function AppointmentForm({
  selectedService,
  setSelectedService,
  mode,
}: {
  selectedService: string;
  setSelectedService: (s: string) => void;
  mode: string;
}) {
  const [errors, setErrors] = useState<FormErrors>({});
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState<{
    message: string;
    id: string;
    mode: string;
  } | null>(null);
  const [failure, setFailure] = useState("");
  const [fileName, setFileName] = useState("");
  const formRef = useRef<HTMLFormElement>(null);
  const submitting = useRef(false);
  const resultRef = useRef<HTMLDivElement>(null);
  const [method, setMethod] = useState("Phone");
  const common = (name: string) => ({
    id: name,
    name,
    "aria-invalid": !!errors[name],
    "aria-describedby": errors[name] ? `${name}-error` : undefined,
  });
  async function submit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (submitting.current) return;
    const form = e.currentTarget;
    const data = new FormData(form);
    const val = (s: string) => String(data.get(s) || "").trim();
    const errs: FormErrors = {};
    if (val("name").length < 2) errs.name = "Please enter your full name.";
    if (
      !/^[+\d()\s.\-]+$/.test(val("phone")) ||
      val("phone").replace(/\D/g, "").length < 10 ||
      val("phone").replace(/\D/g, "").length > 15
    )
      errs.phone = "Please enter a valid phone number.";
    if (!/^\d{5}$/.test(val("zip"))) errs.zip = "Enter a 5-digit ZIP code.";
    if (
      (val("email") && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val("email"))) ||
      (method === "Email" && !val("email"))
    )
      errs.email = "Enter a valid email address.";
    if (!val("date") || val("date") < today())
      errs.date = "Choose today or a future date.";
    if (!data.get("consent"))
      errs.consent = "Please provide your consent to continue.";
    const file = data.get("photo") as File;
    if (
      file?.size &&
      (!["image/jpeg", "image/png", "image/webp"].includes(file.type) ||
        file.size > 5 * 1024 * 1024)
    )
      errs.photo = "Choose a JPG, PNG, or WebP up to 5 MB.";
    setErrors(errs);
    setFailure("");
    if (Object.keys(errs).length) {
      requestAnimationFrame(() =>
        document.getElementById(Object.keys(errs)[0])?.focus(),
      );
      return;
    }
    if (!file?.size) data.delete("photo");
    data.set("consent", "true");
    submitting.current = true;
    setLoading(true);
    try {
      const response = await fetch("/api/appointments", {
        method: "POST",
        body: data,
        signal: AbortSignal.timeout(25000),
      });
      const body = await response.json();
      if (!response.ok) {
        setErrors(body.errors || {});
        throw new Error(body.message || "Your request could not be submitted.");
      }
      setSuccess(body);
      requestAnimationFrame(() => resultRef.current?.focus());
    } catch (err) {
      setFailure(
        err instanceof Error && err.name !== "TimeoutError"
          ? err.message
          : "The connection timed out. We could not confirm delivery. Please try again later.",
      );
    } finally {
      setLoading(false);
      submitting.current = false;
    }
  }
  return (
    <div className="booking-form-wrap reveal">
      {success ? (
        <div className="form-success" ref={resultRef} tabIndex={-1}>
          <span className="success-icon">
            <CircleCheck size={38} />
          </span>
          <span className="micro-label">
            {success.mode === "local"
              ? "SAVED LOCALLY · PREVIEW ONLY"
              : "REQUEST DELIVERED"}
          </span>
          <h3>
            {success.mode === "local"
              ? "Request saved.<br/>Not yet sent."
              : "A good first step."}
          </h3>
          <p>{success.message}</p>
          <p className="request-reference">Reference: {success.id}</p>
          <div className="success-note">
            <Info size={18} />
            <span>
              Your appointment is not confirmed until our team contacts you.
            </span>
          </div>
          <button
            className="button"
            onClick={() => {
              setSuccess(null);
              setFileName("");
              setErrors({});
            }}
          >
            Make another request
            <ArrowUpRight size={17} />
          </button>
        </div>
      ) : (
        <form ref={formRef} noValidate onSubmit={submit}>
          <div className="form-heading">
            <div>
              <span className="micro-label">YOUR NEXT STEP STARTS HERE</span>
              <h3>Request an assessment.</h3>
            </div>
            <ArrowUpRight size={26} strokeWidth={1.4} />
          </div>
          <div
            className={`form-mode ${mode === "connected" ? "connected" : ""}`}
          >
            <Info size={15} />
            <span>
              {mode === "local"
                ? "Preview mode: requests are saved locally, not sent to a roofing team."
                : mode === "connected"
                  ? "Requests are delivered to the configured business integration."
                  : "Delivery status is unavailable. Please check your submission result carefully."}
            </span>
          </div>
          <div className="form-grid">
            <FormField name="name" label="Full name" required errors={errors}>
              <input
                {...common("name")}
                placeholder="Your full name"
                autoComplete="name"
                required
                maxLength={100}
              />
            </FormField>
            <FormField
              name="phone"
              label="Phone number"
              required
              errors={errors}
            >
              <input
                {...common("phone")}
                type="tel"
                placeholder="(555) 000-0000"
                autoComplete="tel"
                required
                maxLength={25}
              />
            </FormField>
            <FormField
              name="email"
              label={
                method === "Email"
                  ? "Email address"
                  : "Email address (optional)"
              }
              required={method === "Email"}
              errors={errors}
            >
              <input
                {...common("email")}
                type="email"
                placeholder="you@example.com"
                autoComplete="email"
                maxLength={254}
              />
            </FormField>
            <FormField
              name="zip"
              label="Property ZIP code"
              required
              errors={errors}
            >
              <input
                {...common("zip")}
                inputMode="numeric"
                placeholder="5-digit ZIP code"
                autoComplete="postal-code"
                maxLength={5}
                required
              />
            </FormField>
            <FormField
              name="propertyType"
              label="Property type"
              errors={errors}
            >
              <div className="select-wrap">
                <select {...common("propertyType")} defaultValue="House">
                  <option>House</option>
                  <option>Townhouse</option>
                  <option>Other</option>
                </select>
                <ChevronDown size={15} />
              </div>
            </FormField>
            <FormField name="service" label="Roofing service" errors={errors}>
              <div className="select-wrap">
                <select
                  {...common("service")}
                  value={selectedService}
                  onChange={(e) => setSelectedService(e.target.value)}
                >
                  {[
                    "Not Sure",
                    "Roof Repair",
                    "Roof Replacement",
                    "Storm Damage",
                    "Roof Inspection",
                  ].map((s) => (
                    <option key={s}>{s}</option>
                  ))}
                </select>
                <ChevronDown size={15} />
              </div>
            </FormField>
            <div className="full-width">
              <FormField
                name="description"
                label="Tell us about your roof (optional)"
                errors={errors}
              >
                <textarea
                  {...common("description")}
                  placeholder="What have you noticed? How can we help?"
                  rows={3}
                  maxLength={3000}
                />
              </FormField>
            </div>
            <FormField
              name="date"
              label="Preferred appointment date"
              required
              errors={errors}
            >
              <input {...common("date")} type="date" min={today()} required />
            </FormField>
            <FormField name="time" label="Preferred time" errors={errors}>
              <div className="select-wrap">
                <select {...common("time")} defaultValue="Flexible">
                  <option>Flexible</option>
                  <option>Morning</option>
                  <option>Afternoon</option>
                </select>
                <ChevronDown size={15} />
              </div>
            </FormField>
            <div className="full-width">
              <FormField
                name="contactMethod"
                label="Preferred contact method"
                errors={errors}
              >
                <div className="contact-options">
                  {["Phone", "Email", "WhatsApp"].map((m) => (
                    <label key={m} className={method === m ? "selected" : ""}>
                      <input
                        type="radio"
                        name="contactMethod"
                        id={m === "Phone" ? "contactMethod" : undefined}
                        value={m}
                        checked={method === m}
                        onChange={() => setMethod(m)}
                      />
                      {m}
                    </label>
                  ))}
                </div>
              </FormField>
            </div>
            <div className="full-width">
              <label className="upload-label" htmlFor="photo">
                <UploadCloud size={22} />
                <span>
                  <strong>{fileName || "Add a roof photo (optional)"}</strong>
                  <small>
                    JPG, PNG, or WebP · Up to 5 MB · No sensitive documents
                  </small>
                </span>
                <Plus size={17} />
                <input
                  {...common("photo")}
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  onChange={(e) => {
                    const f = e.target.files?.[0];
                    setFileName(f?.name || "");
                    setErrors((prev) => ({
                      ...prev,
                      photo:
                        f &&
                        (f.size > 5242880 ||
                          !["image/jpeg", "image/png", "image/webp"].includes(
                            f.type,
                          ))
                          ? "Use a JPG, PNG, or WebP up to 5 MB."
                          : "",
                    }));
                  }}
                />
              </label>
              {errors.photo && (
                <span className="field-error" id="photo-error">
                  {errors.photo}
                </span>
              )}
            </div>
          </div>
          <div className="honeypot" aria-hidden="true">
            <label>
              Website
              <input name="website" tabIndex={-1} autoComplete="off" />
            </label>
          </div>
          <label className="consent">
            <input
              {...common("consent")}
              type="checkbox"
              value="true"
              required
            />
            <span>
              I agree to be contacted about my request and consent to the
              storage and processing of the information I provide. No marketing
              consent is implied.
            </span>
          </label>
          {errors.consent && (
            <span className="field-error" id="consent-error">
              {errors.consent}
            </span>
          )}
          {failure && (
            <div className="form-failure" role="alert">
              {failure}
            </div>
          )}
          <button
            className="button submit-button"
            disabled={loading}
            type="submit"
          >
            {loading ? (
              <>
                <LoaderCircle size={18} className="spin" />
                Saving your request…
              </>
            ) : (
              <>
                Request my appointment
                <ArrowUpRight size={19} />
              </>
            )}
          </button>
          <p className="form-disclaimer">
            Your appointment request is not confirmed until our team contacts
            you.
          </p>
        </form>
      )}
    </div>
  );
}
