import { execFileSync } from "node:child_process";
import { readFile } from "node:fs/promises";

// High-confidence checks, not a substitute for GitHub secret scanning or human review.
const files = execFileSync("git", ["ls-files", "-z"], { encoding: "utf8" })
  .split("\0")
  .filter(Boolean);
if (!files.length)
  throw new Error(
    "No tracked files to inspect. Stage the intended source files first.",
  );
const denied =
  /^(?:data|uploads|backups|node_modules|dist|test-results|artwork-source)\/|(?:^|\/)(?:\.env(?:\..*)?|\.npmrc|\.netrc|credentials\.json)$|\.(?:pem|key|p12|pfx|sqlite3?|db)$/i;
const patterns = [
  /-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----/,
  /\b(?:gh[pousr]_[A-Za-z0-9]{30,}|github_pat_[A-Za-z0-9_]{40,})\b/,
  /\bAKIA[0-9A-Z]{16}\b/,
  /\bsk_live_[A-Za-z0-9]{16,}\b/,
  /https?:\/\/[^\s/]+:[^\s/@]+@github\.com\//i,
];
const failures = [];
for (const file of files) {
  if (file !== ".env.example" && denied.test(file)) {
    failures.push(`${file}: forbidden private/generated path`);
    continue;
  }
  const bytes = await readFile(file);
  if (bytes.includes(0)) continue;
  const text = bytes.toString("utf8");
  if (patterns.some((pattern) => pattern.test(text)))
    failures.push(`${file}: potential credential detected (value hidden)`);
}
if (failures.length) {
  console.error(failures.join("\n"));
  process.exitCode = 1;
} else
  console.log(
    `Repository hygiene passed for ${files.length} tracked files. No matching credentials or private-data paths found. Review still required.`,
  );
