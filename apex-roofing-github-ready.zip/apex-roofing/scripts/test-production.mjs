import { spawn } from "node:child_process";
import { mkdir } from "node:fs/promises";
import { once } from "node:events";

// Run only against an isolated local instance, never a live customer endpoint.
const port = "4173";
const env = {
  ...process.env,
  NODE_ENV: "production",
  PORT: port,
  APPOINTMENT_WEBHOOK_URL: "",
  WEBHOOK_TOKEN: "",
  DATA_DIR: "",
};
await mkdir("test-results", { recursive: true });
const server = spawn(process.execPath, ["server.mjs"], {
  env,
  stdio: ["ignore", "pipe", "inherit"],
});
try {
  await Promise.race([
    new Promise((resolve, reject) => {
      let logs = "";
      server.stdout.on("data", (chunk) => {
        logs += chunk;
        process.stdout.write(chunk);
        if (logs.includes("listening on port")) resolve();
      });
      server.once("error", reject);
      server.once("exit", (code) =>
        reject(new Error(`Test server exited early (${code}).`)),
      );
    }),
    new Promise((_, reject) => {
      const timer = setTimeout(
        () => reject(new Error("Test server startup timed out.")),
        15000,
      );
      timer.unref();
    }),
  ]);
  const response = await fetch(`http://127.0.0.1:${port}/api/health`);
  if (!response.ok) throw new Error("Production health check failed.");
  const tests = spawn(process.execPath, ["tests/e2e.mjs"], {
    env: { ...env, TEST_URL: `http://127.0.0.1:${port}` },
    stdio: "inherit",
  });
  const [code] = await once(tests, "exit");
  if (code !== 0) process.exitCode = code || 1;
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
} finally {
  if (server.exitCode === null && server.signalCode === null) {
    const exited = once(server, "exit");
    server.kill("SIGTERM");
    await exited.catch(() => {});
  }
}
