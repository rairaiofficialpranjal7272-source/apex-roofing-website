## Summary

Describe the website changes and list any existing files that were integrated or changed.

## Verification

- [ ] `npm ci` on Node 22
- [ ] `npm run build`
- [ ] `npm run security:repository`
- [ ] `npx playwright install --with-deps chromium`
- [ ] `npm run test:production`
- [ ] Responsive layout, keyboard interactions, and mobile form reviewed
- [ ] No secrets, real submissions, uploads, or private customer data included
- [ ] GitHub Actions checks passed on this PR

## Deployment notes

- This app requires a Node/Express backend; GitHub Pages alone is insufficient.
- Appointment requests are local-only unless a verified delivery webhook is configured.
- Configure private persistent `DATA_DIR` storage before accepting real submissions.
- Business contact details, service areas, privacy terms, and delivery must be verified before launch.
- A merge is not a deployment. Verify the final public HTTPS URL and request delivery before declaring launch complete.
