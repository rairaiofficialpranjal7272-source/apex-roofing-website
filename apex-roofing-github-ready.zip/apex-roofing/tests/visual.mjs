import { chromium } from "playwright";
const browser = await chromium.launch({ headless: true });
const page = await browser.newPage({
  viewport: { width: 1440, height: 1000 },
  deviceScaleFactor: 1,
});
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
await page.goto("http://localhost:3000", { waitUntil: "networkidle" });
await page.waitForTimeout(3000);
await page.screenshot({ path: "test-results/desktop.png", fullPage: false });
for (const width of [375, 390, 430, 768, 1024, 1440, 1920]) {
  await page.setViewportSize({ width, height: 1000 });
  await page.waitForTimeout(150);
  const check = await page.evaluate(() => ({
    viewport: innerWidth,
    scroll: document.documentElement.scrollWidth,
    broken: [...document.images]
      .filter((i) => !i.complete || i.naturalWidth === 0)
      .map((i) => i.src),
    overflow: [...document.querySelectorAll("body *")]
      .filter((el) => {
        const r = el.getBoundingClientRect();
        return (
          r.right > innerWidth + 2 &&
          getComputedStyle(el).position !== "absolute" &&
          getComputedStyle(el).position !== "fixed"
        );
      })
      .map((el) => el.className)
      .slice(0, 15),
  }));
  console.log(width, JSON.stringify(check));
  if (width === 390)
    await page.screenshot({ path: "test-results/mobile.png", fullPage: false });
}
console.log("Errors", errors);
await browser.close();
