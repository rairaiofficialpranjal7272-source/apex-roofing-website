import { chromium } from "playwright";
import AxeBuilder from "@axe-core/playwright";
import assert from "node:assert/strict";
import { readdir, readFile, rm } from "node:fs/promises";
const browser = await chromium.launch({ headless: true });
const context = await browser.newContext({
  viewport: { width: 1440, height: 1000 },
  reducedMotion: "reduce",
});
const page = await context.newPage();
const errors = [];
page.on("pageerror", (e) => errors.push(e.message));
const base = process.env.TEST_URL || "http://localhost:3000";
await page.goto(base, { waitUntil: "networkidle" });
const report = { viewports: [], tests: [], accessibility: [] };
for (const width of [375, 390, 430, 768, 1024, 1440, 1920]) {
  await page.setViewportSize({ width, height: 1000 });
  const layout = await page.evaluate(() => ({
    viewport: innerWidth,
    document: document.documentElement.scrollWidth,
    brokenImages: [...document.images].filter(
      (i) => !i.complete || !i.naturalWidth,
    ).length,
  }));
  assert.equal(
    layout.viewport,
    layout.document,
    `Horizontal overflow at ${width}`,
  );
  assert.equal(layout.brokenImages, 0);
  report.viewports.push({ width, ...layout });
}
report.tests.push(
  "All seven viewport widths: no horizontal overflow or broken images",
);
await page.setViewportSize({ width: 390, height: 844 });
await page
  .getByRole("button", { name: "Open navigation", exact: true })
  .click();
assert.equal(await page.locator("#mobile-nav").isVisible(), true);
await page
  .locator("#mobile-nav")
  .getByRole("link", { name: "Services" })
  .click();
assert.equal(await page.locator("#mobile-nav").count(), 0);
await page
  .getByRole("button", {
    name: "Learn about Flashing & roof transitions",
    exact: true,
  })
  .click();
await page
  .locator("#roof-detail")
  .getByRole("heading", { name: "Flashing & roof transitions" })
  .waitFor();
await page
  .getByRole("button", { name: "Gutters & roof edges", exact: true })
  .focus();
await page.keyboard.press("Enter");
await page
  .locator("#roof-detail")
  .getByRole("heading", { name: "Gutters & roof edges" })
  .waitFor();
report.tests.push("Mobile navigation and mouse/keyboard roof hotspots");
await page.locator("#area-zip").fill("90210");
await page.getByRole("button", { name: "Check ZIP code", exact: true }).click();
assert.match(
  await page.locator(".zip-result").innerText(),
  /not been published/,
);
await page
  .getByText("How do I know if my roof needs repair?", { exact: true })
  .click();
assert.equal(
  await page.locator(".faq-list details").first().getAttribute("open"),
  "",
);
report.tests.push("Honest ZIP availability and FAQ accordion");
await page.setViewportSize({ width: 1440, height: 1000 });
await page.locator(".header-call").click();
await page.locator("dialog[open]").waitFor();
assert.match(await page.locator("dialog").innerText(), /not been configured/);
await page.keyboard.press("Escape");
assert.equal(await page.locator("dialog[open]").count(), 0);
report.tests.push("Unconfigured phone dialog and Escape dismissal");
await page.locator(".submit-button").click();
assert.ok((await page.locator(".field-error").count()) >= 4);
await page.locator("#name").fill("Preview Test");
await page.locator("#phone").fill("2025550147");
await page.locator("#zip").fill("90210");
const date = await page.evaluate(() => {
  let d = new Date();
  d.setDate(d.getDate() + 2);
  return d.toLocaleDateString("en-CA");
});
await page.locator("#date").fill(date);
await page.getByRole("radio", { name: "Email", exact: true }).check();
await page.locator(".submit-button").click();
assert.match(await page.locator("#email-error").innerText(), /valid email/);
await page.locator("#email").fill("preview-test@example.invalid");
await page.getByRole("radio", { name: "Phone", exact: true }).check();
await page.locator("#consent").check();
await page
  .locator("#photo")
  .setInputFiles({
    name: "roof.png",
    mimeType: "image/png",
    buffer: Buffer.from(
      "89504e470d0a1a0a0000000d49484452000000010000000108060000001f15c4890000000b49444154789c636000020000050001a5f645400000000049454e44ae426082",
      "hex",
    ),
  });
await page.route(
  "**/api/appointments",
  (route) =>
    route.fulfill({
      status: 503,
      contentType: "application/json",
      body: JSON.stringify({
        message: "Test delivery unavailable. No appointment is confirmed.",
      }),
    }),
  { times: 1 },
);
await page.locator(".submit-button").click();
await page.getByRole("alert").waitFor();
assert.match(await page.getByRole("alert").innerText(), /unavailable/);
report.tests.push(
  "Inline validation, conditional email validation, image selection, recoverable server failure",
);
await page.locator(".submit-button").click();
await page.locator(".form-success").waitFor();
assert.match(await page.locator(".form-success").innerText(), /Not yet sent/);
const reference = await page.locator(".request-reference").innerText();
const id = reference.replace("Reference: ", "");
const record = JSON.parse(
  await readFile(`data/appointments/${id}.json`, "utf8"),
);
assert.equal(record.status, "local-only");
assert.equal(record.name, "Preview Test");
await rm(`data/appointments/${id}.json`);
if (record.photo) await rm(`data/appointments/${record.photo}`);
report.tests.push(
  "Real local backend persistence, validated image upload, truthful local success state",
);
const invalid = await page.request.post(base + "/api/appointments", {
  multipart: { name: "x" },
});
assert.equal(invalid.status(), 400);
const fields = {
  name: "Server Validation Test",
  phone: "2025550147",
  email: "",
  zip: "90210",
  propertyType: "House",
  service: "Roof Inspection",
  description: "",
  date,
  time: "Flexible",
  contactMethod: "Phone",
  consent: "true",
};
const spoofed = await page.request.post(base + "/api/appointments", {
  multipart: {
    ...fields,
    photo: {
      name: "not-an-image.png",
      mimeType: "image/png",
      buffer: Buffer.from("not an image"),
    },
  },
});
assert.equal(spoofed.status(), 400);
const past = await page.request.post(base + "/api/appointments", {
  multipart: { ...fields, date: "2000-01-01" },
});
assert.equal(past.status(), 400);
const csrf = await page.request.post(base + "/api/appointments", {
  headers: { origin: "https://untrusted.invalid" },
  multipart: fields,
});
assert.equal(csrf.status(), 403);
report.tests.push(
  "Server rejects invalid fields, spoofed image bytes, past date, and cross-origin submission",
);
await page.reload({ waitUntil: "networkidle" });
// Reveal all sections as a visitor scrolling through the document.
await page.evaluate(async () => {
  for (let y = 0; y < document.body.scrollHeight; y += 700) {
    scrollTo(0, y);
    await new Promise((r) => setTimeout(r, 30));
  }
  scrollTo(0, 0);
});
const a11y = await new AxeBuilder({ page })
  .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
  .analyze();
report.accessibility = a11y.violations.map((v) => ({
  id: v.id,
  impact: v.impact,
  description: v.description,
  nodes: v.nodes.map((n) => ({ target: n.target, summary: n.failureSummary })),
}));
report.consoleErrors = errors;
assert.equal(errors.length, 0);
await page.screenshot({
  path: "test-results/full-desktop.png",
  fullPage: true,
});
await page.setViewportSize({ width: 390, height: 844 });
await page.screenshot({ path: "test-results/full-mobile.png", fullPage: true });
const mobileA11y = await new AxeBuilder({ page })
  .withTags(["wcag2a", "wcag2aa", "wcag21aa"])
  .analyze();
report.mobileAccessibility = mobileA11y.violations.map((v) => ({
  id: v.id,
  nodes: v.nodes.map((n) => ({ target: n.target, summary: n.failureSummary })),
}));
await page
  .locator(".booking-form-wrap")
  .screenshot({ path: "test-results/mobile-form.png" });
await page.setViewportSize({ width: 768, height: 1024 });
await page
  .locator(".booking-section")
  .screenshot({ path: "test-results/tablet-booking.png" });
const { writeFile } = await import("node:fs/promises");
await writeFile("test-results/report.json", JSON.stringify(report, null, 2));
console.log(JSON.stringify(report, null, 2));
await browser.close();
assert.equal(
  report.accessibility.length,
  0,
  "Desktop automated accessibility violations",
);
assert.equal(
  report.mobileAccessibility.length,
  0,
  "Mobile automated accessibility violations",
);
