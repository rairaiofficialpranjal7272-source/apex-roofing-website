// Replace these empty values with verified company information before launch.
export const business = {
  name: "Apex Roofing Co.",
  phone: "", // E.164 format, e.g. +1 followed by your real business number
  phoneDisplay: "",
  email: "",
  location: "",
  hours: "",
  whatsappNumber: "", // Country code and digits only
  serviceAreas: [] as { city: string; zips: string[] }[],
  images: {
    hero: "/images/hero.webp",
    repair: "/images/repair.webp",
    replacement: "/images/replacement.webp",
    inspection: "/images/inspection.webp",
  },
};
export const services = [
  {
    id: "repair",
    number: "01",
    title: "Roof repair & leak detection",
    short: "Roof Repair",
    image: business.images.repair,
    alt: "Detailed view of charcoal shingles, dormer flashing, and a roof edge",
    description:
      "Address roof leaks, damaged shingles, flashing problems, and visible roof wear with a professional assessment.",
    features: [
      "Leak assessment",
      "Shingle repairs",
      "Flashing inspection",
      "Repair recommendations",
    ],
  },
  {
    id: "replacement",
    number: "02",
    title: "Roof replacement & installation",
    short: "Roof Replacement",
    image: business.images.replacement,
    alt: "American home with a prominent charcoal architectural shingle roof",
    description:
      "Explore roofing replacement options designed around your home's structure, appearance, and requirements.",
    features: [
      "Existing roof assessment",
      "Roofing material selection",
      "Shingle replacement",
      "Project planning",
    ],
  },
  {
    id: "storm",
    number: "03",
    title: "Storm damage & roof inspection",
    short: "Storm Damage",
    image: business.images.inspection,
    alt: "Roofing professional checking the condition of residential shingles",
    description:
      "Assess visible storm-related roof damage and understand the recommended next steps.",
    features: [
      "Wind and hail damage assessment",
      "Roof condition inspection",
      "Damage documentation",
      "Repair recommendations",
    ],
  },
];
