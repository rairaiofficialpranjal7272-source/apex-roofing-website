import React, { useEffect, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  ArrowUpRight,
  ArrowRight,
  ArrowDown,
  Phone,
  Menu,
  X,
  Check,
  Plus,
  ShieldCheck,
  Layers3,
  ScanLine,
  MessageCircle,
  MapPin,
  Clock3,
  Info,
  Mail,
} from "lucide-react";
import { business, services } from "./config";
import AppointmentForm from "./AppointmentForm";
import { RoofLogo, Words, Label } from "./ui";
import "./fonts.css";
import "./styles.css";

type DialogKind = "contact" | "whatsapp" | "privacy" | "terms" | null;
const nav = [
  ["Home", "#home"],
  ["Services", "#services"],
  ["Our Work", "#work"],
  ["Process", "#process"],
  ["Contact", "#contact"],
];
const whatsappMessage =
  "Hello, I would like to inquire about your roofing services and request an estimate.";
function App() {
  const [menu, setMenu] = useState(false);
  const [dialog, setDialog] = useState<DialogKind>(null);
  const [selectedService, setSelectedService] = useState("Not Sure");
  const [hotspot, setHotspot] = useState(0);
  const [zip, setZip] = useState("");
  const [zipResult, setZipResult] = useState("");
  const [contactInView, setContactInView] = useState(false);
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => setContactInView(entry.isIntersecting),
      { rootMargin: "0px 0px 70px 0px" },
    );
    const section = document.querySelector("#contact");
    if (section) observer.observe(section);
    return () => observer.disconnect();
  }, []);
  const [bookingMode, setBookingMode] = useState<
    "local" | "connected" | "unknown"
  >("unknown");
  const menuButton = useRef<HTMLButtonElement>(null);
  const dialogRef = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    fetch("/api/booking-status")
      .then((r) => r.json())
      .then((d) => setBookingMode(d.mode))
      .catch(() => setBookingMode("unknown"));
  }, []);
  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) =>
        entries.forEach((e) => {
          if (e.isIntersecting) {
            e.target.classList.add("visible");
            observer.unobserve(e.target);
          }
        }),
      { threshold: 0.12 },
    );
    document.querySelectorAll(".reveal").forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);
  useEffect(() => {
    if (dialog) dialogRef.current?.showModal();
    else dialogRef.current?.close();
  }, [dialog]);
  useEffect(() => {
    const fn = (e: KeyboardEvent) => {
      if (e.key === "Escape" && menu) {
        setMenu(false);
        menuButton.current?.focus();
      }
    };
    document.addEventListener("keydown", fn);
    return () => document.removeEventListener("keydown", fn);
  }, [menu]);
  useEffect(() => {
    const motion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const hero = document.querySelector<HTMLElement>(".hero");
    let frame = 0;
    const onMove = (e: PointerEvent) => {
      if (motion.matches || e.pointerType !== "mouse") return;
      cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        hero?.style.setProperty(
          "--px",
          `${(e.clientX / window.innerWidth - 0.5) * 8}px`,
        );
        hero?.style.setProperty(
          "--py",
          `${(e.clientY / window.innerHeight - 0.5) * 5}px`,
        );
      });
    };
    hero?.addEventListener("pointermove", onMove);
    return () => {
      hero?.removeEventListener("pointermove", onMove);
      cancelAnimationFrame(frame);
    };
  }, []);
  function estimate(service = "Not Sure") {
    setSelectedService(service);
    setMenu(false);
    document.querySelector("#contact")?.scrollIntoView({
      behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches
        ? "instant"
        : "smooth",
    });
  }
  function call(e: React.MouseEvent) {
    if (!business.phone) {
      e.preventDefault();
      setDialog("contact");
    }
  }
  function whatsapp(e: React.MouseEvent) {
    if (!business.whatsappNumber) {
      e.preventDefault();
      setDialog("whatsapp");
    }
  }
  const roofDetails = [
    {
      title: "Architectural shingles",
      tag: "01 / THE FIRST LINE OF DEFENSE",
      text: "Shingles form the outer weather-shedding layer of your roof. Missing, lifted, or visibly worn shingles are a reason to arrange a closer assessment.",
      x: "58%",
      y: "35%",
    },
    {
      title: "Flashing & roof transitions",
      tag: "02 / SMALL DETAILS. BIG PURPOSE.",
      text: "Flashing helps guide water away from joints, walls, and roof penetrations. An assessment can check for visible gaps, wear, or loose sections.",
      x: "36%",
      y: "46%",
    },
    {
      title: "Gutters & roof edges",
      tag: "03 / KEEP WATER MOVING",
      text: "Gutters and roof edges help direct rainwater away from your home. Overflowing gutters, loose edges, or visible buildup may need attention.",
      x: "72%",
      y: "65%",
    },
  ];
  function checkZip(e: React.FormEvent) {
    e.preventDefault();
    if (!/^\d{5}$/.test(zip))
      return setZipResult("Please enter a valid 5-digit ZIP code.");
    if (!business.serviceAreas.length)
      return setZipResult(
        "Service areas have not been published yet. Include your ZIP code in an estimate request so the team can confirm availability.",
      );
    const area = business.serviceAreas.find((a) => a.zips.includes(zip));
    setZipResult(
      area
        ? `Your ZIP code is in our published ${area.city} service area. Request an assessment to confirm scheduling.`
        : "This ZIP code is not in our published service area. Please contact the team to check availability.",
    );
  }
  return (
    <>
      <a className="skip-link" href="#main">
        Skip to content
      </a>
      <section className="hero" id="home" aria-labelledby="hero-heading">
        <div className="hero-scene">
          <img
            className="hero-image"
            src={business.images.hero}
            alt="Beautiful American home with charcoal shingle roofs and warmly lit windows at blue hour"
            fetchPriority="high"
          />
          <div className="hero-shade" />
          <div className="cloud-glow" />
        </div>
        <div className="hero-grid" aria-hidden="true">
          {[0, 1, 2, 3].map((i) => (
            <span key={i} style={{ "--i": i } as React.CSSProperties} />
          ))}
        </div>
        <div className="particles" aria-hidden="true">
          {Array.from({ length: 9 }, (_, i) => (
            <i
              key={i}
              style={{
                left: `${8 + i * 10}%`,
                top: `${20 + ((i * 19) % 64)}%`,
                animationDelay: `${i * 0.7}s`,
              }}
            />
          ))}
        </div>
        <header className="header">
          <a
            href="#home"
            aria-label="Apex Roofing Co. home"
            className="logo-entry"
          >
            <RoofLogo />
          </a>
          <nav className="desktop-nav" aria-label="Main navigation">
            {nav.map(([label, href], i) => (
              <a
                key={label}
                href={href}
                className={i === 0 ? "active" : ""}
                style={{ animationDelay: `${0.15 + i * 0.07}s` }}
              >
                {label}
              </a>
            ))}
          </nav>
          <div className="header-actions">
            <a
              className="header-call"
              href={business.phone ? `tel:${business.phone}` : "#contact"}
              onClick={call}
              aria-label="Call Apex Roofing Co."
            >
              <Phone size={15} />
              <span>Call Us</span>
            </a>
            <button className="button button-sm" onClick={() => estimate()}>
              Get Free Estimate <ArrowUpRight size={16} />
            </button>
            <button
              className="menu-toggle"
              aria-label={menu ? "Close navigation" : "Open navigation"}
              aria-expanded={menu}
              aria-controls="mobile-nav"
              ref={menuButton}
              onClick={() => setMenu(!menu)}
            >
              {menu ? <X /> : <Menu />}
            </button>
          </div>
          {menu && (
            <nav
              className="mobile-nav"
              id="mobile-nav"
              aria-label="Mobile navigation"
            >
              {nav.map(([label, href], i) => (
                <a key={label} href={href} onClick={() => setMenu(false)}>
                  <span className="nav-number">0{i + 1}</span>
                  {label}
                  <ArrowUpRight size={18} />
                </a>
              ))}
              <button onClick={() => estimate()} className="button">
                Get a free estimate
                <ArrowUpRight size={17} />
              </button>
            </nav>
          )}
        </header>
        <div className="hero-copy">
          <div className="hero-eyebrow">
            <span className="tiny-dot" />
            <Words
              text="RESIDENTIAL ROOFING • QUALITY CRAFTSMANSHIP"
              delay={0.3}
            />
          </div>
          <h1 id="hero-heading">
            <Words text="PROTECT WHAT" delay={0.5} />
            <br />
            <Words text="MATTERS MOST." delay={0.7} />
          </h1>
          <p className="hero-description">
            <Words
              text="Expert roof repairs, replacements, and storm damage solutions designed to protect your home and give you peace of mind."
              delay={0.95}
              step={0.035}
            />
          </p>
          <div className="hero-buttons">
            <button className="button" onClick={() => estimate()}>
              Get a free estimate
              <ArrowUpRight size={19} />
            </button>
            <a className="text-button" href="#services">
              Explore our services
              <ArrowDown size={17} />
            </a>
          </div>
          <div className="hero-assurance">
            <span>
              <Check size={13} /> A considered approach
            </span>
            <span>
              <Check size={13} /> Built around your home
            </span>
          </div>
        </div>
        <div className="priority-card">
          <div className="priority-icon">
            <ShieldCheck size={27} strokeWidth={1.4} />
          </div>
          <div>
            <span className="micro-label">MORE THAN A ROOF.</span>
            <p>
              Your home.
              <br />
              Our priority.
            </p>
          </div>
          <span className="status-dot" />
        </div>
        <div className="hero-bottom">
          <a href="#services" className="scroll-note">
            <span className="scroll-ring">
              <ArrowDown size={15} />
            </span>
            SCROLL TO DISCOVER
          </a>
          <p>
            Thoughtful roofing. <span>Lasting peace of mind.</span>
          </p>
          <span className="hero-index">01 — 07</span>
        </div>
      </section>
      <main id="main">
        <section
          className="services section-pad"
          id="services"
          aria-labelledby="services-heading"
        >
          <div className="section-top reveal">
            <div>
              <Label number="01">EXPERTISE, ABOVE ALL</Label>
              <h2 id="services-heading">
                A better roof.
                <br />
                <span className="muted">A better peace of mind.</span>
              </h2>
            </div>
            <div className="section-intro">
              <p>
                From the first inspection to the final detail, thoughtful
                solutions for the place you call home.
              </p>
              <a
                href="#contact"
                className="small-link"
                onClick={() => setSelectedService("Not Sure")}
              >
                Find the right solution
                <ArrowUpRight size={17} />
              </a>
            </div>
          </div>
          <div className="service-grid">
            {services.map((service, i) => (
              <article
                className="service-card reveal"
                key={service.id}
                id={`service-${service.id}`}
                style={
                  { "--reveal-delay": `${i * 0.12}s` } as React.CSSProperties
                }
              >
                <a
                  className="service-image"
                  href="#contact"
                  onClick={() => setSelectedService(service.short)}
                  aria-label={`Request ${service.short.toLowerCase()}`}
                >
                  <img src={service.image} alt={service.alt} loading="lazy" />
                  <span className="image-number">/ {service.number}</span>
                  <span className="circle-arrow">
                    <ArrowUpRight size={23} />
                  </span>
                </a>
                <div className="service-content">
                  <h3>{service.title}</h3>
                  <p>{service.description}</p>
                  <ul>
                    {service.features.map((f) => (
                      <li key={f}>
                        <Check size={13} />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <button
                    className="service-link"
                    onClick={() => estimate(service.short)}
                  >
                    Explore service
                    <ArrowUpRight size={16} />
                  </button>
                </div>
              </article>
            ))}
          </div>
        </section>
        <section
          className="roof-section section-pad"
          id="roof"
          aria-labelledby="roof-heading"
        >
          <div className="roof-header reveal">
            <div>
              <Label number="02" light>
                KNOW WHAT'S OVERHEAD
              </Label>
              <h2 id="roof-heading">
                Every detail.
                <br />
                Working together.
              </h2>
            </div>
            <p>
              A well-considered roof is a system, not just a surface. Take a
              closer look at the details that help protect your home.
            </p>
          </div>
          <div className="roof-explorer reveal">
            <div className="roof-visual">
              <img
                src={business.images.repair}
                alt="Interactive roof view showing shingles, dormer flashing, and gutters"
                loading="lazy"
              />
              <div className="visual-shade" />
              <span className="image-kicker">
                <ScanLine size={15} /> EXPLORE YOUR ROOF
              </span>
              {roofDetails.map((item, i) => (
                <button
                  key={item.title}
                  className={`hotspot ${hotspot === i ? "selected" : ""}`}
                  style={{ left: item.x, top: item.y }}
                  onClick={() => setHotspot(i)}
                  aria-label={`Learn about ${item.title}`}
                  aria-pressed={hotspot === i}
                  aria-controls="roof-detail"
                >
                  <Plus size={18} />
                  <span className="hotspot-tooltip">{item.title}</span>
                </button>
              ))}
              <span className="visual-note">SELECT A POINT TO EXPLORE</span>
            </div>
            <div className="roof-detail" id="roof-detail" aria-live="polite">
              <span className="detail-tag">{roofDetails[hotspot].tag}</span>
              <div className="detail-icon">
                {hotspot === 0 ? (
                  <Layers3 size={33} strokeWidth={1.2} />
                ) : hotspot === 1 ? (
                  <ShieldCheck size={33} strokeWidth={1.2} />
                ) : (
                  <ScanLine size={33} strokeWidth={1.2} />
                )}
              </div>
              <h3>{roofDetails[hotspot].title}</h3>
              <p>{roofDetails[hotspot].text}</p>
              <button
                className="text-button"
                onClick={() => estimate("Roof Inspection")}
              >
                Arrange an inspection
                <ArrowUpRight size={18} />
              </button>
              <div className="detail-pager" aria-label="Roof components">
                {roofDetails.map((item, i) => (
                  <button
                    key={item.title}
                    onClick={() => setHotspot(i)}
                    aria-label={item.title}
                    aria-pressed={i === hotspot}
                    className={i === hotspot ? "active" : ""}
                  >
                    0{i + 1}
                  </button>
                ))}
              </div>
            </div>
          </div>
          <p className="inspection-note">
            <Info size={13} /> An illustration, not a diagnosis. A photograph
            cannot reveal hidden damage or confirm structural condition.
          </p>
        </section>
        <section
          className="projects section-pad"
          id="work"
          aria-labelledby="work-heading"
        >
          <div className="section-top reveal">
            <div>
              <Label number="03">THE POSSIBILITIES, IN PERSPECTIVE</Label>
              <h2 id="work-heading">
                Crafted to protect.
                <br />
                <span className="muted">Built to last.</span>
              </h2>
            </div>
            <div className="section-intro">
              <p>
                Beautiful roofs. Considered details. Explore the possibilities
                for your home.
              </p>
              <span className="example-label">
                ILLUSTRATIVE EXAMPLES · NOT COMPLETED PROJECTS
              </span>
            </div>
          </div>
          <div className="project-grid">
            {[
              {
                title: "Architectural shingle roofing",
                category: "MATERIAL & CHARACTER",
                image: business.images.repair,
                description:
                  "Dimensional texture and a refined finish that complements the home.",
              },
              {
                title: "Residential roof replacement",
                category: "A FRESH PERSPECTIVE",
                image: business.images.replacement,
                description:
                  "A cohesive roofline, thoughtfully considered from every angle.",
              },
              {
                title: "Storm damage repair",
                category: "CARE & RESTORATION",
                image: business.images.inspection,
                description:
                  "A closer look at visible wear, with a clear path to the next step.",
              },
            ].map((p, i) => (
              <article
                className="project-card reveal"
                key={p.title}
                style={
                  { "--reveal-delay": `${i * 0.12}s` } as React.CSSProperties
                }
              >
                <div className="project-image">
                  <img
                    src={p.image}
                    alt={p.title + " — AI-generated illustrative example"}
                    loading="lazy"
                  />
                  <span>ILLUSTRATIVE EXAMPLE</span>
                </div>
                <div className="project-meta">
                  <span>{p.category}</span>
                  <span>0{i + 1}</span>
                </div>
                <h3>{p.title}</h3>
                <p>{p.description}</p>
              </article>
            ))}
          </div>
        </section>
        <section
          className="why-section"
          id="approach"
          aria-labelledby="why-heading"
        >
          <div className="why-image reveal">
            <img
              src={business.images.replacement}
              alt="Thoughtfully designed American home and architectural shingle roof"
              loading="lazy"
            />
            <div className="image-caption">
              <span className="tiny-dot" /> YOUR HOME DESERVES A THOUGHTFUL
              APPROACH.
            </div>
          </div>
          <div className="why-copy reveal">
            <Label number="04">THE APEX APPROACH</Label>
            <h2 id="why-heading">
              Confidence
              <br />
              starts at the top.
            </h2>
            <p className="why-intro">
              Roofing decisions should feel clear, not complicated. Here’s what
              matters to us.
            </p>
            <div className="benefits">
              {[
                {
                  icon: MessageCircle,
                  title: "Clear communication",
                  text: "Straightforward conversations, with space for your questions.",
                },
                {
                  icon: ScanLine,
                  title: "Detailed roof assessments",
                  text: "A careful look at visible conditions before recommendations.",
                },
                {
                  icon: Layers3,
                  title: "Thoughtful material recommendations",
                  text: "Options considered for your home, your priorities, and your roof.",
                },
                {
                  icon: ShieldCheck,
                  title: "Quality-focused workmanship",
                  text: "An approach centered on the details that make a difference.",
                },
              ].map((b) => (
                <div className="benefit" key={b.title}>
                  <span className="benefit-icon">
                    <b.icon size={20} strokeWidth={1.5} />
                  </span>
                  <div>
                    <h3>{b.title}</h3>
                    <p>{b.text}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
        <section
          className="process section-pad"
          id="process"
          aria-labelledby="process-heading"
        >
          <div className="section-top reveal">
            <div>
              <Label number="05">CLEAR FROM THE START</Label>
              <h2 id="process-heading">
                Good roofing.
                <br />
                <span className="muted">No guesswork.</span>
              </h2>
            </div>
            <div className="section-intro">
              <p>
                A straightforward path from your first question to your next
                step.
              </p>
              <button className="small-link" onClick={() => estimate()}>
                Let’s get started
                <ArrowUpRight size={17} />
              </button>
            </div>
          </div>
          <ol className="process-grid">
            {[
              { title: "Request", text: "Tell us about your roofing needs." },
              {
                title: "Inspect",
                text: "Arrange a professional roof assessment.",
              },
              {
                title: "Get an estimate",
                text: "Review the recommended work and available options.",
              },
              {
                title: "Plan the project",
                text: "Confirm the details and arrange the next steps.",
              },
            ].map((s, i) => (
              <li
                className="process-step reveal"
                key={s.title}
                style={
                  { "--reveal-delay": `${i * 0.12}s` } as React.CSSProperties
                }
              >
                <div className="step-top">
                  <span>0{i + 1}</span>
                  <ArrowRight size={21} />
                </div>
                <h3>{s.title}</h3>
                <p>{s.text}</p>
              </li>
            ))}
          </ol>
        </section>
        <section
          className="booking-section section-pad"
          id="contact"
          aria-labelledby="booking-heading"
        >
          <div className="booking-copy reveal">
            <Label number="06" light>
              LET'S TALK ABOUT YOUR HOME
            </Label>
            <h2 id="booking-heading">
              Let’s take care
              <br />
              of your roof.
            </h2>
            <p>
              Tell us a little about your home and what’s on your mind. Start
              with a request, and take the next step with clarity.
            </p>
            <div className="booking-photo">
              <img
                src={business.images.hero}
                alt="Welcoming home with warm evening light and a charcoal roof"
                loading="lazy"
              />
              <span>
                <ShieldCheck size={19} /> YOUR HOME. OUR PRIORITY.
              </span>
            </div>
            <a
              className="contact-phone"
              href={business.phone ? `tel:${business.phone}` : "#contact"}
              onClick={call}
            >
              <span className="contact-icon">
                <Phone size={19} />
              </span>
              <span>
                <small>PREFER A CONVERSATION?</small>
                {business.phoneDisplay || "Contact our team"}
              </span>
              <ArrowUpRight size={20} />
            </a>
            <div className="contact-extras">
              {business.email && (
                <a href={`mailto:${business.email}`}>
                  <Mail size={15} />
                  {business.email}
                </a>
              )}
              {business.location && (
                <span>
                  <MapPin size={15} />
                  {business.location}
                </span>
              )}
              <a
                href={
                  business.whatsappNumber
                    ? `https://wa.me/${business.whatsappNumber}?text=${encodeURIComponent(whatsappMessage)}`
                    : "#contact"
                }
                onClick={whatsapp}
                target={business.whatsappNumber ? "_blank" : undefined}
                rel="noreferrer"
              >
                <MessageCircle size={15} /> Ask via WhatsApp
                <ArrowUpRight size={14} />
              </a>
            </div>
          </div>
          <AppointmentForm
            selectedService={selectedService}
            setSelectedService={setSelectedService}
            mode={bookingMode}
          />
        </section>
        <section
          className="questions section-pad"
          id="faq"
          aria-labelledby="faq-heading"
        >
          <div className="area-block reveal">
            <Label number="07">CLOSER TO HOME</Label>
            <h2>
              Good roofs.
              <br />
              <span className="muted">Local care.</span>
            </h2>
            <p>
              {business.serviceAreas.length
                ? `Explore availability in ${business.serviceAreas.map((a) => a.city).join(", ")}.`
                : "Every home starts with a location. Check your ZIP code to see our current service-area information."}
            </p>
            <form className="zip-form" onSubmit={checkZip}>
              <label htmlFor="area-zip" className="sr-only">
                Your ZIP code
              </label>
              <MapPin size={18} />
              <input
                id="area-zip"
                placeholder="Enter your ZIP code"
                inputMode="numeric"
                autoComplete="postal-code"
                maxLength={5}
                value={zip}
                onChange={(e) => setZip(e.target.value.replace(/\D/g, ""))}
              />
              <button aria-label="Check ZIP code">
                <ArrowRight size={20} />
              </button>
            </form>
            <p className="zip-result" aria-live="polite">
              {zipResult}
            </p>
            <span className="area-note">
              Availability is confirmed by the team before scheduling.
            </span>
          </div>
          <div className="faq-block reveal">
            <span className="micro-label">
              A LITTLE CLARITY GOES A LONG WAY
            </span>
            <h2 id="faq-heading">
              Your questions.
              <br />
              Straight answers.
            </h2>
            <div className="faq-list">
              {[
                [
                  "How do I know if my roof needs repair?",
                  "Missing or lifted shingles, water stains, visible flashing damage, or debris in gutters can be reasons to request an assessment. Some issues are not visible from the ground. Avoid climbing onto your roof yourself.",
                ],
                [
                  "When should I replace my roof?",
                  "There is no single replacement age for every roof. Material, installation, ventilation, weather exposure, and current condition all matter. A professional assessment can help you compare repair and replacement options.",
                ],
                [
                  "What should I do if my roof starts leaking?",
                  "Keep people away from wet ceilings and electrical hazards. If it is safe, contain dripping water and move belongings. Contact a roofing professional. Do not climb onto a wet or storm-damaged roof. If there is immediate danger, contact emergency services.",
                ],
                [
                  "Can you inspect storm damage?",
                  "A storm damage assessment can look for visible signs of wind, hail, and debris damage and document observed conditions. It does not guarantee insurance coverage or determine hidden structural damage.",
                ],
                [
                  "What happens during an inspection?",
                  "An assessment typically covers accessible roof surfaces, shingles, flashing, roof edges, and visible drainage issues. Findings, limitations, and recommended next steps should be discussed with you before work is planned.",
                ],
                [
                  "How do I request an estimate?",
                  "Use the appointment request form and describe what you have noticed. In this preview, requests are stored locally unless a delivery integration is connected. No visit is confirmed until the team contacts you.",
                ],
                [
                  "Do you serve my ZIP code?",
                  "Use the ZIP checker on this page. If service areas have not been published, include your ZIP code in a request so availability can be confirmed directly.",
                ],
              ].map(([q, a]) => (
                <details key={q}>
                  <summary>
                    {q}
                    <Plus size={18} />
                  </summary>
                  <p>{a}</p>
                </details>
              ))}
            </div>
          </div>
        </section>
        <section className="final-cta section-pad">
          <div className="final-grid" aria-hidden="true" />
          <div className="reveal">
            <Label light>IT ALL STARTS WITH A CONVERSATION</Label>
            <h2>
              Give your home the
              <br />
              protection it deserves.
            </h2>
            <p>Let’s discuss your roof and find the right next step.</p>
            <div className="final-buttons">
              <button
                className="button button-white"
                onClick={() => estimate()}
              >
                Get a roofing estimate
                <ArrowUpRight size={18} />
              </button>
              <a
                className="text-button"
                href={business.phone ? `tel:${business.phone}` : "#contact"}
                onClick={call}
              >
                <Phone size={16} />
                Call our team
              </a>
            </div>
          </div>
          <svg
            className="cta-roof"
            viewBox="0 0 500 350"
            fill="none"
            aria-hidden="true"
          >
            <path
              d="M0 330 250 80l250 250M65 350l185-185 185 185M150 350l100-100 100 100"
              stroke="currentColor"
              strokeWidth="2"
            />
          </svg>
        </section>
      </main>
      <footer className="footer section-pad">
        <div className="footer-top">
          <div className="footer-brand">
            <a href="#home" aria-label="Apex Roofing home">
              <RoofLogo />
            </a>
            <p>
              A thoughtful approach to residential roofing.
              <br />
              Protecting what makes a house your home.
            </p>
          </div>
          <div>
            <h3>EXPLORE</h3>
            <a href="#services">Our services</a>
            <a href="#work">Roofing examples</a>
            <a href="#process">Our process</a>
            <a href="#faq">Common questions</a>
          </div>
          <div>
            <h3>LET'S CONNECT</h3>
            <button onClick={() => estimate()}>
              Request an estimate
              <ArrowUpRight size={13} />
            </button>
            <a
              href={business.phone ? `tel:${business.phone}` : "#contact"}
              onClick={call}
            >
              {business.phoneDisplay || "Contact our team"}
            </a>
            {business.email && (
              <a href={`mailto:${business.email}`}>{business.email}</a>
            )}
            <a href="#faq">Service-area availability</a>
            <span className="footer-hours">
              <Clock3 size={13} />
              {business.hours || "Hours to be confirmed"}
            </span>
          </div>
          <div className="footer-note">
            <span className="tiny-dot" />
            <p>
              Better decisions.
              <br />
              Better roofing.
            </p>
            <a href="#home" aria-label="Back to top" className="back-top">
              <ArrowUpRight size={20} />
            </a>
          </div>
        </div>
        <div className="footer-bottom">
          <span>
            © {new Date().getFullYear()} {business.name} All rights reserved.
          </span>
          <span className="footer-legal">
            <button onClick={() => setDialog("privacy")}>Privacy Policy</button>
            <button onClick={() => setDialog("terms")}>Terms of Service</button>
          </span>
        </div>
        <p className="preview-note">
          Website preview · Architectural images are AI-generated illustrations.
          Business contact details and service areas are pending configuration.
        </p>
      </footer>
      {!contactInView && !dialog && (
        <div className="mobile-contact">
          <a
            href={business.phone ? `tel:${business.phone}` : "#contact"}
            onClick={call}
            aria-label="Call our team"
          >
            <Phone size={18} />
          </a>
          <button onClick={() => estimate()}>
            Request an estimate
            <ArrowUpRight size={17} />
          </button>
        </div>
      )}
      <dialog
        className="info-dialog"
        ref={dialogRef}
        onCancel={() => setDialog(null)}
        onClick={(e) => {
          if (e.target === dialogRef.current) setDialog(null);
        }}
        aria-labelledby="dialog-heading"
      >
        <button
          className="dialog-close"
          aria-label="Close dialog"
          onClick={() => setDialog(null)}
        >
          <X size={21} />
        </button>
        {dialog === "contact" || dialog === "whatsapp" ? (
          <>
            <div className="dialog-icon">
              {dialog === "whatsapp" ? <MessageCircle /> : <Phone />}
            </div>
            <span className="micro-label">CONTACT CONFIGURATION</span>
            <h2 id="dialog-heading">Let’s stay honest.</h2>
            <p>
              {dialog === "whatsapp"
                ? "A business WhatsApp number has not been configured yet. No message has been sent."
                : "A business phone number has not been configured yet. We won’t connect you to a placeholder number."}
            </p>
            <p>
              You can explore the request form. Preview requests are stored
              locally unless a live delivery integration is enabled.
            </p>
            <button
              className="button"
              onClick={() => {
                setDialog(null);
                estimate();
              }}
            >
              Open request form
              <ArrowUpRight size={17} />
            </button>
          </>
        ) : (
          <>
            <span className="micro-label">PREVIEW WEBSITE POLICY</span>
            <h2 id="dialog-heading">
              {dialog === "privacy" ? "Privacy policy" : "Terms of service"}
            </h2>
            {dialog === "privacy" ? (
              <>
                <p>
                  This preview collects only the details you submit: contact
                  information, property ZIP code, roof concerns, appointment
                  preferences, consent, and an optional image. Do not upload
                  sensitive documents or images containing people.
                </p>
                <p>
                  In local mode, submissions and images are stored in the
                  website server’s private local request inbox. They are not
                  emailed or sent to a roofing company. If a webhook is
                  configured, submissions are delivered to that configured
                  processor. Only authorized website administrators should have
                  server access.
                </p>
                <p>
                  There are no advertising trackers or analytics cookies on this
                  preview. Browser preferences and form state are not used for
                  marketing. Before public launch, the operator must publish
                  verified contact details, retention and deletion procedures,
                  and a complete privacy policy for the configured hosting and
                  processors.
                </p>
              </>
            ) : (
              <>
                <p>
                  This is a website preview. Its content provides general
                  roofing information, not a diagnosis, binding estimate,
                  emergency response, warranty, or contract for services.
                </p>
                <p>
                  Appointment requests are not confirmed bookings. In preview
                  mode, requests are stored locally and are not delivered to a
                  roofing business. Work scope, pricing, availability,
                  scheduling, and any warranty must be agreed separately with
                  the verified provider.
                </p>
                <p>
                  All architectural imagery is AI-generated and illustrative,
                  not a portfolio of completed customer projects. Do not climb
                  onto a roof or rely on a photograph to assess structural
                  safety. The operator must review these terms before public
                  launch.
                </p>
              </>
            )}
          </>
        )}
      </dialog>
    </>
  );
}
createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
);
