import React from "react";
import { business } from "./config";
export function RoofLogo({ compact = false }: { compact?: boolean }) {
  return (
    <span className="brand">
      <svg
        className="brand-mark"
        viewBox="0 0 48 38"
        fill="none"
        aria-hidden="true"
      >
        <path
          d="M3 25 24 5l21 20M10 31l14-14 14 14M18 36l6-6 6 6"
          stroke="currentColor"
          strokeWidth="3.4"
        />
      </svg>
      <span>
        {business.name.split(" ")[0].toUpperCase()}
        <span className="brand-sub">
          {business.name.split(" ").slice(1).join(" ").toUpperCase()}
        </span>
      </span>
      {!compact && <span className="sr-only">{business.name}</span>}
    </span>
  );
}
export function Words({
  text,
  delay = 0,
  step = 0.06,
  className = "",
}: {
  text: string;
  delay?: number;
  step?: number;
  className?: string;
}) {
  return (
    <span className={`words ${className}`}>
      <span className="sr-only">{text}</span>
      {text.split(" ").map((word, i) => (
        <React.Fragment key={i}>
          <span
            className="word"
            aria-hidden="true"
            style={{ "--delay": `${delay + i * step}s` } as React.CSSProperties}
          >
            {word}
          </span>
          {i < text.split(" ").length - 1 ? " " : null}
        </React.Fragment>
      ))}
    </span>
  );
}
export function Label({
  number,
  children,
  light = false,
}: {
  number?: string;
  children: React.ReactNode;
  light?: boolean;
}) {
  return (
    <div className={`section-label ${light ? "light" : ""}`}>
      <span className="label-line" />
      {number && <span className="label-number">{number} /</span>}
      {children}
    </div>
  );
}
